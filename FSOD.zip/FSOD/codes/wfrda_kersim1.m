function kersim=wfrda_kersim(a,x,e)
if (e==-1)
    if (a==x)
       kersim=0;
    else
       kersim=1;
    end
else
     kersim=abs(a-x);    
end
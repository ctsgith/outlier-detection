function [score]=FSOD(trandata,m,rho)


[~,kk]=size(trandata);
kk=kk-1;
alpha1=0;

for j=1:kk
    if min(trandata(:,j))==0&&max(trandata(:,j))==1
       alpha=std(trandata(:,j));         
   else
        alpha=1/kk;
    end
    alpha1=alpha1+alpha;
end
germ=round(alpha1,2);
if germ<alpha1             %standard deviation
        alpha=germ/alpha1*m;
    else
        alpha=alpha1/germ*m;
end

[simility1,score1]=FRS1(trandata,alpha); 
ma=max(score1);         %Algorithm 1 FS-NWOD Normalisation
mi=min(score1); 
score1=(score1-mi)./(ma-mi);

[score2]=FRS2(trandata,alpha,simility1); 
ma=max(score2);        %Algorithm 2 FS-DROD Normalisation
mi=min(score2);
score2=(score2-mi)./(ma-mi);

score=rho*score1+(1-rho)*score2;    %FSOD

clc
clear
load ('filename')

m=;        %Fuzzy threshold adjustment parameter. Range 0-1, the step size is 0.05.
rho=;     %algorithmic weighting factor. Range 0-1,  the step size is 0.1.

scores=FSOD(trandata,m,rho);
labels=trandata(:,end);
[FPR, TPR, ~, AUC] = perfcurve(labels, scores, 1);       %AUC
disp(['AUC=',num2str(AUC)])

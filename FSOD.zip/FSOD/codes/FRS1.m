function [simility1,score]=FRS11(data,alpha)
[n,m]=size(data);
m=m-1;
score=zeros(n,1);
simility1=0;

delta=zeros(1,m);          
delta=delta-1;
for i=1:m                         
    if all(data(:,i)<=1)
     delta(i)=alpha; %Find the radius of the numeric feature
    end
end

for i=1:m             %Algorithm WFS
    x=data(:,i); 
    for qq=1:n      
         for ww=1:qq
              distance1(qq,ww)=wfrda_kersim1(x(qq),x(ww),delta(i));    
              distance1(ww,qq)=distance1(qq,ww);                          %Compute relation matrice
        end
    end        

      AQ=0;
      if sum(sum(distance1))==0
         continue
      else
         maxd=max(max(distance1));
         mind=min(min(distance1));
         distance=(distance1-mind)./(maxd-mind);
         sim=(1-distance);
         sim(sim<alpha)=0;

         for j=1:n                                        
              AQ=-(1/n)*log2(sum(sim(j,:))/n)+AQ;    %Calculate attribute information entropy
        end

        simility1=simility1+sim.*AQ;
        A(1,i)=AQ;
       end
end

v=sum(A);                       
simility1=simility1./v;
simility2=sum(simility1,2);
DD=diag(simility2);
simility5=DD^-1*simility1;         %Normalisation by rows ( calculate neighbourhood significance matrice)

for i=1:n                                    %fuzzy neighborhood-weighted information matrix
     simility3(i,1)=(simility1(i,:)*simility2)/n;
end
simility=simility3;

for i=1:n                  
     FRS11(i,1)=-1/n*log2(sum(simility(i,:))/n);
end

for i=1:n                               %FS-NWOD
     score(i,1)=simility5(i,:)*FRS11;
end

  



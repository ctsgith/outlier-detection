function [score]=FRS10(data,~,simility1)
[n,m]=size(data);
m=m-1;
score=zeros(n,1);

simility3=sum(simility1,2);
DD=diag(simility3);
simility20=DD^-1*simility1;
sim1=sum(simility1,2);

   for i=1:n                         
        for j=1:n                               
            simility3(i,j)=sim1(i,1)/sim1(j,1);   %ratio matrix
            simility4(i,j)=1-abs(sim1(i,1)-sim1(j,1));         %difference matrix    
       end
  end

maxd=max(max(simility3));                  %Ratio matrix normalisation
mind=min(min(simility3));                    
simility5=(simility3-mind)./(maxd-mind);

maxd1=max(max(simility4));                %Difference matrix normalisation
mind1=min(min(simility4));    
simility6=(simility4-mind1)./(maxd1-mind1);

simility10=(simility6+simility5)/2;           
simility11=simility20.*simility10;           

    for j=1:n                                        %FS-DROD
        score(j,:)=score(j,:)+-(1/n)*log2(sum(simility11(j,:))/n); 
    end
   
